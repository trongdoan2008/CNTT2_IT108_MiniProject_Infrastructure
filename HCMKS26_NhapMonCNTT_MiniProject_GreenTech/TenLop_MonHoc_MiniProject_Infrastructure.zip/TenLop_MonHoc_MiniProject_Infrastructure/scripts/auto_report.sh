#!/usr/bin/env bash
# auto_report.sh - ban Linux/macOS cua auto_report.bat
# AUDIT: chi doc log, chi ghi noi (>>), khong co lenh xoa.
set -euo pipefail
cd "$(dirname "$0")/.."
LOG="data/log-he-thong.log"
OUT="backup/bao-cao-su-co.txt"
[ -f "$LOG" ] || { echo "[LOI] Khong tim thay $LOG"; exit 1; }
mkdir -p backup
{
  echo "=============================================="
  echo "  BAO CAO SU CO HE THONG - GREENTECH"
  echo "  Thoi diem tao bao cao: $(date '+%F %T')"
  echo "  Nguon: $LOG"
  echo "=============================================="
} >> "$OUT"
cat "$LOG" | grep -E "CRITICAL|ERROR|TIMEOUT" >> "$OUT" || true
CNT=$(grep -cE "CRITICAL|ERROR|TIMEOUT" "$LOG" || true)
{
  echo "----------------------------------------------"
  echo "  Tong so dong loi nghiem trong: $CNT"
  echo "----------------------------------------------"
  echo
} >> "$OUT"
echo "[OK] Da ghi bao cao vao $OUT ($CNT dong loi)."
